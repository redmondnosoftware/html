<?php
// Define debbuging
define("IS_DEBBUG", false);

define("MAIL_USER", "redmondalarmsx@gmail.com");
define("MAIL_PWD", "Viamonte1621");
define("HOSTNAME", "{imap.gmail.com:993/imap/ssl}INBOX");
define("SUBJECT_KEY", "SMTP se encuentra funcionando correctamente." );

//Estado de las plataformas
define("PROBLEM", "0" );
define("OK", "1" );
define("RECOVERY", "2" );

define("SUBJECT_PROBLEM"," [PROBLEM] Chequeo de SMTP de la plataforma: CRITICAL");
define("SUBJECT_RECOVERY"," [RECOVERY] Chequeo de SMTP de la plataforma: RECOVERY");
define("BODY_INTRO","El servicio SMTP de la plataforma");
define("BODY_PROBLEM","no se encuentra funcionando, 
                 por lo que no llegar&aacute;n las notificaciones de Nagios del mismo. <br/> 
                 Se debe notificar a Tigo de este error indicando que: si no funciona el servicio SMTP nuestro sistema de monitoreo 
                 no nos podr&aacute; notificar sobre fallas en la plataforma.");

define("BODY_RECOVERY","Se ha restablecido el servicio SMTP, 
                          Si continuan llegando estas alarmas se debe notificar a Tigo del error indicando que: el servicio SMTP de nuestro sistema de monitoreo 
                          est&aacute; trabajando con demoras, y si no se resuelve, el SMTP no nos podr&aacute; notificar sobre fallas en la plataforma.");                 

// Defino a quienes se les envian los correos
$arrayOfAddress['facu'] = 'facundo.daranno@redmondsoftware.com';
?>